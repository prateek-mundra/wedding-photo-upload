"""
Google Drive integration for the Wedding Photo Upload System.

Auth strategy: Service Account.
  1. Create a Google Cloud project -> enable "Google Drive API".
  2. Create a Service Account -> generate a JSON key -> save as
     backend/service_account.json (keep this OUT of git).
  3. Create a Drive folder (e.g. "Nicku & Shruti Wedding Photos") in YOUR
     personal Drive and SHARE it with the service account's email
     (looks like xxxx@xxxx.iam.gserviceaccount.com) as Editor.
  4. Put that folder's ID in .env as DRIVE_ROOT_FOLDER_ID
     (the ID is the long string in the folder's URL after /folders/).

Note: Files uploaded by a service account normally count against the
service account's own (0-byte) storage quota, NOT yours, UNLESS you
upload directly into a folder that a real Google account (you) owns and
has shared with the service account -- which is exactly what step 3
does. That's why sharing an existing folder (not creating a new one via
the API) is important.
"""

import io
import os
from functools import lru_cache

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload

from config import get_settings

SCOPES = ["https://www.googleapis.com/auth/drive"]


@lru_cache
def get_drive_service():
    settings = get_settings()
    if not os.path.exists(settings.google_service_account_file):
        raise RuntimeError(
            f"Missing {settings.google_service_account_file}. See drive_service.py "
            "docstring for setup steps."
        )
    if not settings.drive_root_folder_id:
        raise RuntimeError("DRIVE_ROOT_FOLDER_ID is not set in .env")

    creds = service_account.Credentials.from_service_account_file(
        settings.google_service_account_file, scopes=SCOPES
    )
    return build("drive", "v3", credentials=creds, cache_discovery=False)


@lru_cache(maxsize=64)
def get_or_create_event_folder(event_name: str) -> str:
    """Return the folder ID for a given event (e.g. 'haldi', 'reception'),
    creating it under ROOT_FOLDER_ID the first time it's requested."""
    service = get_drive_service()
    root_folder_id = get_settings().drive_root_folder_id
    safe_name = event_name.strip().lower() or "general"

    query = (
        f"'{root_folder_id}' in parents "
        f"and mimeType='application/vnd.google-apps.folder' "
        f"and name='{safe_name}' and trashed=false"
    )
    results = service.files().list(q=query, fields="files(id, name)").execute()
    files = results.get("files", [])
    if files:
        return files[0]["id"]

    metadata = {
        "name": safe_name,
        "mimeType": "application/vnd.google-apps.folder",
        "parents": [root_folder_id],
    }
    folder = service.files().create(body=metadata, fields="id").execute()
    return folder["id"]


def upload_file_bytes(
    file_bytes: bytes,
    filename: str,
    mimetype: str,
    event_name: str = "general",
) -> dict:
    """Uploads raw bytes to the Drive folder for `event_name`.
    Returns {id, name, webViewLink}.
    """
    service = get_drive_service()
    folder_id = get_or_create_event_folder(event_name)

    media = MediaIoBaseUpload(io.BytesIO(file_bytes), mimetype=mimetype, resumable=True)
    metadata = {"name": filename, "parents": [folder_id]}

    uploaded = (
        service.files()
        .create(body=metadata, media_body=media, fields="id, name, webViewLink, size")
        .execute()
    )
    return uploaded


def list_event_files(event_name: str = "general") -> list:
    service = get_drive_service()
    folder_id = get_or_create_event_folder(event_name)
    query = f"'{folder_id}' in parents and trashed=false"
    results = (
        service.files()
        .list(
            q=query,
            fields="files(id, name, mimeType, webViewLink, thumbnailLink, createdTime, size)",
            orderBy="createdTime desc",
            pageSize=200,
        )
        .execute()
    )
    return results.get("files", [])
